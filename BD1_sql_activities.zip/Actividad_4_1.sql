create database jardineria;
use jardineria;
/* Workbench no soporta el comando source, se importaran los datos utilizando una nueva pestana para abrir el archivo */


create database nba;
use nba;
/* insertando las tablas y datos desde la pestana del archivo */


/* Consultas de la actividad en turno: */
/* 1.- Obtener la ciudad y telefono de las oficinas ubicadas en EEUU */
select ciudad, telefono from oficinas where pais='EEUU';
/*
Boston			+1 215 837 0825
San Francisco	+1 650 219 4782
*/

select nombre, apellido1, apellido2, email from empleados where codigojefe=3;
/*
Felipe Rosas Marquez		frosas@jardineria.es
Juan Carlos	Ortiz Serrano	cortiz@jardineria.es
Carlos	Soria Jimenez		csoria@jardineria.es
Emmanuel Magaña	Perez		manu@jardineria.es
Francois Fignon				ffignon@gardening.com
Michael	Bolton				mbolton@gardening.com
Hilary Washington			hwashington@gardening.com
Nei	Nishikori				nnishikori@gardening.com
Amy	Johnson					ajohnson@gardening.com
Kevin Fallmer				kfalmer@gardening.com
*/

select puesto, nombre, apellido1, email from empleados where codigojefe is null;
/*
'Director General', 'Marcos', 'Magaña', 'marcos@jardineria.es'
*/

select nombre, apellido1, puesto from empleados where puesto <> 'Representante Ventas';
/*
Marcos, Magaña, 	Director General
Ruben, López, 		Subdirector Marketing
Alberto, Soria, 	Subdirector Ventas
Maria, Solís, 		Secretaria
Carlos, Soria, 		Director Oficina
Emmanuel, Magaña, 	Director Oficina
Francois, Fignon,	Director Oficina
Michael, Bolton, 	Director Oficina
Hilary, Washington, Director Oficina
Nei, Nishikori, 	Director Oficina
Amy, Johnson, 		Director Oficina
Kevin, Fallmer, 	Director Oficina
*/

select count(*) from clientes;
/*
# count(*)
'36'
*/

/*'España'*/
select nombrecliente from clientes where pais='España';
/*
'Beragua'
'Club Golf Puerta del hierro'
'Naturagua'
'DaraDistribuciones'
'Madrileña de riegos'
'Jardin de Flores'
'Flores Marivi'
'Flowers, S.A'
'Naturajardin'
'Golf S.A.'
'AYMERICH GOLF MANAGEMENT, SL'
'Aloha'
'El Prat'
'Sotogrande'
'Vivero Humanes'
'Fuenla City'
'Jardines y Mansiones CACTUS SL'
'Jardinerías Matías SL'
'Agrojardin'
'Top Campo'
'Jardineria Sara'
'Campohermoso'
'FLORES S.L.'
*/

select distinct(pais), count(*) from clientes group by pais;
/*
USA				 4
Spain			 4
España			23
France			 2
Australia		 2
United Kingdom	 1
*/

select ciudad, count(*) from clientes where ciudad = 'Madrid';
/*
Madrid	11
*/

select count(*) from clientes where ciudad like 'M%';
select ciudad, count(*) from clientes where ciudad like 'M%' group by ciudad;
/*
# count(*): '14'
Miami					 2
Madrid					11
Montornes del valles	 1
*/

select codigoempleadorepventas, count(*) from clientes group by codigoempleadorepventas;
/*
# codigoempleadorepventas, count(*)
'5', 						'5'
'8', 						'4'
'9', 						'2'
'11', 						'5'
'12', 						'5'
'16', 						'2'
'18', 						'2'
'19', 						'2'
'22', 						'2'
'30', 						'5'
'31', 						'2'
*/

select count(*) from clientes where codigoempleadorepventas is null;
/*
# count(*)
'0'
*/

(select * from pagos order by fechapago asc limit 1) 
union 
(select * from pagos order by fechapago desc limit 1);
/*
# CodigoCliente, FormaPago, 		IDTransaccion, 		FechaPago, 		Cantidad
'5', 			'Transferencia', 	'ak-std-000011', 	'2006-01-18', 	'23794.00'
'23', 			'PayPal', 			'ak-std-000019', 	'2009-03-26', 	  '272.00'
*/

select codigocliente, fechapago from pagos where fechapago > '2007-12-31' and fechapago < '2009-01-01';
/*
# codigocliente, fechapago
'1', 			'2008-11-10'
'1', 			'2008-12-10'
'13', 			'2008-08-04'
'14', 			'2008-07-15'
'26', 			'2008-03-18'
*/

select distinct(estado) from pedidos;
/*
# estado
'Entregado'
'Rechazado'
'Pendiente'
'Pediente'
*/

select codigopedido, codigocliente, fechaesperada, fechaentrega, estado from pedidos where fechaesperada<fechaentrega and estado='Entregado';
/*
# codigopedido, codigocliente, fechaesperada, fechaentrega
'9', '1', '2008-12-27', '2008-12-28', 'Entregado'
'13', '7', '2009-01-14', '2009-01-15', 'entregado'
'16', '7', '2009-01-07', '2009-01-15', 'entregado'
'17', '7', '2009-01-09', '2009-01-11', 'entregado'
'18', '9', '2009-01-06', '2009-01-07', 'entregado'
'22', '9', '2009-01-11', '2009-01-13', 'entregado'
'28', '3', '2009-02-17', '2009-02-20', 'Entregado'
'32', '4', '2007-01-19', '2007-01-27', 'Entregado'
'38', '19', '2009-03-06', '2009-03-07', 'Entregado'
'42', '19', '2009-03-23', '2009-03-27', 'Entregado'
'45', '23', '2009-03-04', '2009-03-07', 'Entregado'
'49', '26', '2008-07-22', '2008-07-23', 'Entregado'
'55', '14', '2009-01-10', '2009-01-11', 'Entregado'
'60', '1', '2008-12-27', '2008-12-28', 'Entregado'
'68', '3', '2009-02-17', '2009-02-20', 'Entregado'
'92', '27', '2009-04-30', '2009-05-03', 'Entregado'
'96', '35', '2008-04-12', '2008-04-13', 'Entregado'
'114', '36', '2009-01-29', '2009-01-31', 'Entregado'
*/
use jardineria;
select * from detallepedidos;
select  distinct(numerolinea), count(codigoproducto) from detallepedidos group by numerolinea;
/*
# numerolinea, count(codigoproducto)
'3', 			'58'
'1', 			'90'
'2', 			'82'
'4', 			'30'
'5', 			'19'
'6', 			 '8'
'7', 			 '4'
'8', 			 '1'
*/

select distinct(codigoproducto), count(codigoproducto) as conteo from detallepedidos group by codigoproducto order by conteo desc limit 20;
/*
# codigoproducto, conteo
'30310', 			'8'
'11679', 			'7'
'22225', 			'7'
'OR-227', 			'7'
'FR-11', 			'7'
'21636', 			'6'
'OR-157', 			'6'
'AR-009', 			'6'
'OR-247', 			'6'
'OR-208', 			'6'
'FR-85', 			'5'
'FR-94', 			'5'
'AR-001', 			'4'
'AR-006', 			'4'
'FR-87', 			'4'
'FR-1', 			'4'
'FR-100', 			'4'
'FR-108', 			'4'
'FR-53', 			'4'
'FR-84', 			'3'
*/

select codigopedido, codigocliente, fechaesperada, fechaentrega, estado from pedidos where fechaesperada>adddate(fechaentrega,2);
/*
# codigopedido, codigocliente, fechaesperada, fechaentrega, estado
'24', 				'14', 		'2008-07-31', '2008-07-25', 'Entregado'
'30',				'13', 		'2008-09-03', '2008-08-31', 'Entregado'
'36', 				'14', 		'2008-12-15', '2008-12-10', 'Entregado'
'53', 				'13', 		'2008-11-15', '2008-11-09', 'Entregado'
'89', 				'35', 		'2007-12-13', '2007-12-10', 'Entregado'
'93', 				'27', 		'2009-05-30', '2009-05-17', 'Entregado'
*/

select * from detallepedidos;

with baseimponible as (
    select 
        round(sum(preciounidad * cantidad), 2) as base
    from detallepedidos
)
select
    base as subtotal,
    round(base * 0.16, 2) AS iva,
    round(base * 1.16, 2) AS total
from baseimponible;
/*
subtotal, 		iva, 		total
'199538.00', '31926.08', '231464.08'
*/

with baseimponible as (
    select 
		distinct(codigoproducto) as codigo,
        round(sum(preciounidad * cantidad), 2) as base
    from detallepedidos 
		where codigoproducto like 'FR%' 
		group by codigoproducto
)
select
	baseimponible.codigo,
    base as subtotal,
    round(base * 0.16, 2) AS iva,
    round(base * 1.16, 2) AS total
from baseimponible;
/*
codigo, 	subtotal, 			iva, 		total
'FR-1', 	  '168.00', 	  '26.88', 		 '194.88'
'FR-10', 	  '119.00', 	  '19.04', 		 '138.04'
'FR-100', 	 '1209.00', 	 '193.44', 		'1402.44'
'FR-101', 	  '247.00', 	  '39.52', 		 '286.52'
'FR-102', 	  '668.00', 	 '106.88', 		 '774.88'
'FR-103', 	   '25.00', 	   '4.00', 		  '29.00'
'FR-105', 	  '280.00', 	  '44.80', 		 '324.80'
'FR-106', 	  '673.00', 	 '107.68', 		 '780.68'
'FR-107', 	 '1100.00', 	 '176.00', 		'1276.00'
'FR-108', 	  '468.00', 	  '74.88', 		 '542.88'
'FR-11', 	'13092.00', 	'2094.72', 	   '15186.72'
'FR-12', 	  '668.00', 	 '106.88', 		 '774.88'
'FR-13', 	  '741.00', 	 '118.56', 		 '859.56'
'FR-15', 	  '225.00', 	  '36.00', 		 '261.00'
'FR-16', 	   '45.00', 	   '7.20', 		  '52.20'
'FR-17', 	  '846.00', 	 '135.36', 		 '981.36'
'FR-18', 	  '108.00', 	  '17.28', 		 '125.28'
'FR-2', 		'7.00', 	   '1.12', 		   '8.12'
'FR-22', 	   '40.00', 	   '6.40', 		  '46.40'
'FR-23', 	   '62.00', 	   '9.92', 		  '71.92'
'FR-29', 	  '960.00', 	 '153.60', 		'1113.60'
'FR-3', 	  '497.00', 	  '79.52', 		 '576.52'
'FR-31', 	   '96.00', 	  '15.36', 		 '111.36'
'FR-33', 	  '216.00', 	  '34.56', 		 '250.56'
'FR-34', 	  '336.00', 	  '53.76', 		 '389.76'
'FR-36', 	  '621.00', 	  '99.36', 		 '720.36'
'FR-37', 	   '45.00', 	   '7.20', 		  '52.20'
'FR-4', 	 '2552.00', 	 '408.32', 		'2960.32'
'FR-40', 	  '434.00', 	  '69.44', 		 '503.44'
'FR-41', 	   '96.00', 	  '15.36', 		 '111.36'
'FR-42', 	   '96.00', 	  '15.36', 		 '111.36'
'FR-43', 	   '48.00', 	   '7.68', 		  '55.68'
'FR-45', 	  '112.00', 	  '17.92', 		 '129.92'
'FR-47', 	  '440.00', 	  '70.40', 		 '510.40'
'FR-48', 	 '1080.00', 	 '172.80', 		'1252.80'
'FR-53', 	  '744.00', 	 '119.04', 		 '863.04'
'FR-54',	  '351.00', 	  '56.16', 		 '407.16'
'FR-56', 	  '128.00', 	  '20.48', 		 '148.48'
'FR-57', 	 '1624.00', 	 '259.84', 		'1883.84'
'FR-58', 	  '561.00', 	  '89.76', 		 '650.76'
'FR-6', 	  '112.00', 	  '17.92', 		 '129.92'
'FR-60', 	  '352.00', 	  '56.32', 		 '408.32'
'FR-64', 	  '110.00', 	  '17.60', 		 '127.60'
'FR-66', 	  '245.00', 	  '39.20', 		 '284.20'
'FR-67', 	 '1750.00', 	 '280.00', 		'2030.00'
'FR-69', 	 '1911.00', 	 '305.76', 		'2216.76'
'FR-7', 	  '348.00', 	  '55.68', 		 '403.68'
'FR-71', 	  '220.00', 	  '35.20', 		 '255.20'
'FR-72', 	  '124.00', 	  '19.84', 		 '143.84'
'FR-75', 	  '224.00', 	  '35.84', 		 '259.84'
'FR-77', 	 '1035.00', 	 '165.60', 		'1200.60'
'FR-78', 	   '30.00', 	   '4.80', 		  '34.80'
'FR-79', 	  '946.00', 	 '151.36', 		'1097.36'
'FR-8', 	  '108.00', 	  '17.28', 		 '125.28'
'FR-80', 	   '32.00', 	   '5.12', 		  '37.12'
'FR-81', 	  '147.00', 	  '23.52', 		 '170.52'
'FR-82', 	  '980.00', 	 '156.80', 		'1136.80'
'FR-84', 	  '143.00', 	  '22.88', 		 '165.88'
'FR-85', 	 '5320.00', 	 '851.20', 		'6171.20'
'FR-86', 	   '22.00', 	   '3.52', 		  '25.52'
'FR-87', 	 '1584.00', 	 '253.44', 		'1837.44'
'FR-89', 	  '450.00', 	  '72.00', 		 '522.00'
'FR-9', 	  '232.00', 	  '37.12', 		 '269.12'
'FR-90', 	  '280.00', 	  '44.80', 		 '324.80'
'FR-91', 	 '2250.00', 	 '360.00', 		'2610.00'
'FR-94', 	 '1649.00', 	 '263.84', 		'1912.84'
*/