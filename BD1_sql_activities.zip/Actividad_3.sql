create database Actividad3;

use actividad3;

/* Ejercicio 1*/
create table ex1_proveedor (
	nfi varchar(9) primary key, 
    nombre varchar(30), 
    direccion varchar(60)
);
create table ex1_cliente (
	dni varchar(9) primary key, 
    nombre varchar(30), 
    apellidos varchar(30), 
    direccion varchar(60)
);
create table ex1_producto (
	codigo int auto_increment primary key, 
    nombre varchar(30), 
    precio float, 
    proveedor varchar(9),
    FOREIGN KEY (proveedor) references ex1_proveedor(nfi)
);
create table ex1_prod_cli (
	id int auto_increment primary key,
	fecha date, 
    folio varchar(10),
    codigo int,
    cliente varchar(9),
    FOREIGN KEY (codigo) references ex1_producto(codigo), 
    FOREIGN KEY (cliente) references ex1_cliente(dni)
);

drop table ex1_prod_cli;
describe table ex1_prod_cli;

/* Ejercicio 2*/
create table ex2_camion (
	matricula varchar(10) primary key, 
	modelo varchar(15), 
    tipo varchar(15), 
    potencia varchar(10)
);
create table ex2_camionero (
	dni varchar(9) primary key, 
    nombre varchar(30),
    direccion varchar(60), 
    telefono varchar(11), 
    poblacion varchar(30), 
    salario float
);
create table ex2_provincia (
	codigo int auto_increment primary key, 
    nombre varchar(30)
);
create table ex2_paquete (
	codigo int auto_increment primary key, 
    descripcion varchar(60), 
    destinatario varchar(30), 
    direccion varchar(60), 
    provincia int,
    FOREIGN KEY (provincia) references ex2_provincia(codigo), 
    camionero varchar(9),
    FOREIGN KEY (camionero) references ex2_camionero(dni)
);
create table ex2_camion_camionero (
	folio int auto_increment primary key, 
    fecha date, 
    camion varchar(11),
    FOREIGN KEY (camion) references ex2_camion(matricula), 
    camionero varchar(9),
    FOREIGN KEY (camionero) references ex2_camionero(dni)
);

/* Ejercicio 3*/
create table ex3_profesor (
	dni varchar(9) primary key,
    nombre varchar(30),
    direccion varchar(60),
    telefono varchar(11)
);
create table ex3_modulo (
	codigo varchar(9) primary key,
    nombre varchar(30),
    profesor varchar(9),
    FOREIGN KEY (profesor) references ex3_profesor(dni)
);
create table ex3_alumno (
	expediente varchar(9) primary key,
    nombre varchar(30),
    apellido varchar(30),
    fec_nac date
);
create table ex3_grupo (
	codigo varchar(9) primary key,
    delegado varchar(9),
    FOREIGN KEY (delegado) references ex3_alumno(expediente),
    modulo varchar(9),
    FOREIGN KEY (modulo) references ex3_modulo(codigo)
);
create table ex3_mod_alum (
	codigo varchar(9) primary key,
    alumno varchar(9),
    FOREIGN KEY (alumno) references ex3_alumno(expediente),
    modulo varchar(9),
    FOREIGN KEY (modulo) references ex3_modulo(codigo)
);

/*Ejercicio 4*/
create table ex4_cliente (
	dni varchar(9) primary key,
    nombre varchar(30),
    direccion varchar(60),
    ciudad varchar(30),
    telefono varchar(11)
);
create table ex4_coche (
	matricula varchar(9) primary key,
    marca varchar(15),
    modelo varchar(15),
    color varchar(30),
    precio float,
    cliente varchar(9),
    FOREIGN KEY (cliente) references ex4_cliente(dni)
);
create table ex4_revision (
	codigo varchar(9) primary key,
    cambios varchar(60),
    fecha date,
    matricula varchar(9),
    FOREIGN KEY (matricula) references ex4_coche(matricula)
);

/*Ejercicio 5*/
create table ex5_medico (
	codigo varchar(9) primary key,
    nombre varchar(30),
    apellido varchar(30),
    especialidad varchar(20),
    telefono varchar(11)
);
create table ex5_paciente (
	codigo varchar(9) primary key,
    nombre varchar(30),
    apellido varchar(30),
	direccion varchar(60),
    telefono varchar(11),
    poblacion varchar(30),
	provincia varchar(30),
    codigo_postal varchar(5),
    fec_nac date
);
create table ex5_ingreso (
	codigo int auto_increment primary key,
    habitacion varchar(15),
    cama int,
    doctor varchar(9),
    FOREIGN KEY (doctor) references ex5_medico(codigo),
    paciente varchar(9),
    FOREIGN KEY (paciente) references ex5_paciente(codigo)
);