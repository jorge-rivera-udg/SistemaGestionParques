create database SiGePaVe;

use SiGePaVe;

create table administradores (
	id int auto_increment primary key,
    nombres varchar(30) not null,
    apellidos varchar(30) not null,
    usuario varchar(20) not null unique,
    email varchar(50) not null unique,
    fdn date not null,
    contrasena varchar(50) not null,
    telefono varchar(15),
    avatar longblob,
    rol enum('SUPER','ADMIN','CONSULTOR','USUARIO') not null default 'USUARIO',
    estado enum('ACTIVO','INACTIVO','BAJA') not null default 'INACTIVO',
    creado_en datetime not null default current_timestamp,
    modificado_en datetime not null default current_timestamp
) engine=InnoDB default charset=utf8mb4;
describe administradores;
drop table administradores;
select * from administradores; 
update administradores set avatar="" where id=1;

INSERT INTO administradores (nombres, apellidos, email, telefono, estado, rol, contrasena, fdn, usuario, avatar) VALUES 
("Jorge", "Rivera", "giorgio1@gmail.com", "3322261517", "OTRO", "ADMIN", "qwe123", current_timestamp , "jra1", "");

SELECT * FROM administradores WHERE usuario="jra" AND contrasena="qwe123";

create table usuarios (
    usuario varchar(30) primary key,
    nombres varchar(30) not null,
    apellidos varchar(30) not null,
    email varchar(50) not null unique,
    contrasena varchar(50) not null
) engine=InnoDB default charset=utf8mb4;
describe usuarios;
drop table usuarios;
select * from usuarios; 

create table imagenes (
	id int auto_increment primary key,
    imagen longblob not null,
    fuente enum('PERFIL','PARQUES','REPORTES','ACTIVIDADES') not null,
    fuente_id int not null,
    usuario varchar(30) not null,
	foreign key (usuario) references administradores(usuario)
) engine=InnoDB default charset=utf8mb4;
describe imagenes;
drop table imagenes;
select * from imagenes; 

create table roles (
	id int auto_increment primary key,
    nombre varchar(30) not null
) engine=InnoDB default charset=utf8mb4;
describe roles;
drop table roles;
select * from roles; 

create table estados (
	id int auto_increment primary key,
    nombre varchar(30) not null
) engine=InnoDB default charset=utf8mb4;
describe estados;
drop table estados;
select * from estados; 

create table categorias (
	id int auto_increment primary key,
    nombre varchar(30) not null
) engine=InnoDB default charset=utf8mb4;
describe categorias;
drop table categorias;
select * from categorias; 

create table condiciones (
	id int auto_increment primary key,
    nombre varchar(30) not null
) engine=InnoDB default charset=utf8mb4;
describe condiciones;
drop table condiciones;
select * from condiciones; 

create table parques (
	id int auto_increment primary key,
    nombre varchar(30) not null,
    ubicacion longtext not null,
    condicion int not null,
    foreign key (condicion) references condiciones(id)
) engine=InnoDB default charset=utf8mb4;
describe parques;
drop table parques;
select * from parques; 

create table actividades (
	id int auto_increment primary key,
    nombre varchar(30) not null,
    fecha datetime,
    descripcion longtext,
    parque int not null,
    categoria int not null, 
    foreign key (parque) references parques(id),
    foreign key (categoria) references categorias(id)
) engine=InnoDB default charset=utf8mb4;
describe actividades;
drop table actividades;
select * from actividades; 

create table reportes (
	id int auto_increment primary key,
    descripcion longtext not null,
    fecha datetime,
    estado int not null,
    usuario varchar(30) not null,
    parque int not null,
    categoria int not null,
    foreign key (estado) references estados(id),
    foreign key (usuario) references administradores(usuario),
    foreign key (parque) references parques(id),
    foreign key (categoria) references categorias(id)
) engine=InnoDB default charset=utf8mb4;
describe reportes;
drop table reportes;
select * from reportes; 

create table participaciones (
	usuario varchar(30) not null,
    actividad int not null,
    foreign key (usuario) references administradores(usuario),
    foreign key (actividad) references actividades(id)
)engine=InnoDB default charset=utf8mb4;
ALTER TABLE participaciones ADD CONSTRAINT uk_usuario_actividad UNIQUE (usuario, actividad);
describe participaciones;
drop table participaciones;
select * from participaciones;

delete from participaciones where usuario='plopez' and actividad=2;

select version();
SET GLOBAL max_allowed_packet = 64 * 1024 * 1024;