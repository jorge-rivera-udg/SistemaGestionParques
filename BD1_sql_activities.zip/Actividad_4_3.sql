use jardineria;
/*1. Obtener el nombre de los clientes, el nombre de sus representantes y la ciudad de la oficina a la que pertenece cada representante.*/
select nombrecliente, nombre, o.ciudad from clientes as c join empleados as e join oficinas as o on e.codigooficina = o.codigooficina and codigoempleado = codigoempleadorepventas order by nombre asc;
/*
nombrecliente						nombre			ciudad
Beragua								Emmanuel		Barcelona
Club Golf Puerta del hierro			Emmanuel		Barcelona
Naturagua							Emmanuel		Barcelona
DaraDistribuciones					Emmanuel		Barcelona
Madrileña de riegos					Emmanuel		Barcelona
Flores Marivi						Felipe			Talavera de la Reina
Flowers, S.A						Felipe			Talavera de la Reina
Fuenla City							Felipe			Talavera de la Reina
Top Campo							Felipe			Talavera de la Reina
Jardineria Sara						Felipe			Talavera de la Reina
AYMERICH GOLF MANAGEMENT, SL		José Manuel		Barcelona
Aloha								José Manuel		Barcelona
Golf S.A.							José Manuel		Barcelona
El Prat								José Manuel		Barcelona
Sotogrande							José Manuel		Barcelona
Jardin de Flores					Julian			Sydney
Naturajardin						Julian			Sydney
Vivero Humanes						Julian			Sydney
Agrojardin							Julian			Sydney
Campohermoso						Julian			Sydney
france telecom						Lionel			Paris
Musée du Louvre						Lionel			Paris
Gerudo Valley						Lorena			Boston
Tendo Garden						Lorena			Boston
Jardines y Mansiones CACTUS SL		Lucio			Madrid
Jardinerías Matías SL				Lucio			Madrid
Lasas S.A.							Mariano			Madrid
Lasas S.A.							Mariano			Madrid
Camunas Jardines S.L.				Mariano			Madrid
Dardena S.A.						Mariano			Madrid
El Jardin Viviente S.L				Mariko			Sydney
Tutifruti S.A						Mariko			Sydney
FLORES S.L.							Michael			San Francisco
THE MAGIC GARDEN					Michael			San Francisco
Gardening Associates				Walter Santiago	San Francisco
DGPRODUCTIONS GARDEN				Walter Santiago	San Francisco
*/
select * from pagos;
/*2. Extraer la misma información que en la pregunta anterior, pero únicamente de clientes que no hayan realizado pagos.*/
select nombrecliente, nombre, o.ciudad from clientes as c join empleados as e join oficinas as o on e.codigooficina = o.codigooficina and codigoempleado = codigoempleadorepventas and c.codigocliente not in (
	select codigocliente from pagos
) order by nombre asc;
/*
nombrecliente					nombre			ciudad
Club Golf Puerta del hierro		Emmanuel		Barcelona
DaraDistribuciones				Emmanuel		Barcelona
Madrileña de riegos				Emmanuel		Barcelona
Flowers, S.A					Felipe			Talavera de la Reina
Fuenla City						Felipe			Talavera de la Reina
Top Campo						Felipe			Talavera de la Reina
AYMERICH GOLF MANAGEMENT, SL	José Manuel		Barcelona
Aloha							José Manuel		Barcelona
El Prat							José Manuel		Barcelona
Naturajardin					Julian			Sydney
Vivero Humanes					Julian			Sydney
Campohermoso					Julian			Sydney
france telecom					Lionel			Paris
Musée du Louvre					Lionel			Paris
Lasas S.A.						Mariano			Madrid
Lasas S.A.						Mariano			Madrid
FLORES S.L.						Michael			San Francisco
THE MAGIC GARDEN				Michael			San Francisco
*/

/*3. Generar una lista con el nombre de los empleados junto con el nombre de sus respectivos jefes.*/
select a.nombre as empleado, b.nombre as jefe from empleados as a join empleados as b on b.codigoempleado = a.codigojefe order by b.nombre asc;
/*
empleado			jefe
Felipe				Alberto
Juan Carlos			Alberto
Carlos				Alberto
Emmanuel			Alberto
Francois			Alberto
Michael				Alberto
Hilary				Alberto
Nei					Alberto
Amy					Alberto
Kevin				Alberto
Larry				Amy
John				Amy
Mariano				Carlos
Lucio				Carlos
Hilario				Carlos
José Manuel			Emmanuel
David				Emmanuel
Oscar				Emmanuel
Lionel				Francois
Laurent				Francois
Marcus				Hilary
Lorena				Hilary
Julian				Kevin
Mariko				Kevin
Ruben				Marcos
Walter Santiago		Michael
Narumi				Nei
Takuma				Nei
Alberto				Ruben
Maria				Ruben
*/

/*4. Identificar el nombre de los clientes a los que no se les ha entregado a tiempo un pedido (FechaEntrega > FechaEsperada).*/
select nombrecliente from clientes as c join pedidos as p on fechaentrega > fechaesperada group by nombrecliente order by nombrecliente;
/*
Agrojardin
Aloha
AYMERICH GOLF MANAGEMENT, SL
Beragua
Campohermoso
Camunas Jardines S.L.
Club Golf Puerta del hierro
DaraDistribuciones
Dardena S.A.
DGPRODUCTIONS GARDEN
El Jardin Viviente S.L
El Prat
Flores Marivi
FLORES S.L.
Flowers, S.A
france telecom
Fuenla City
Gardening Associates
Gerudo Valley
Golf S.A.
Jardin de Flores
Jardineria Sara
Jardinerías Matías SL
Jardines y Mansiones CACTUS SL
Lasas S.A.
Madrileña de riegos
Musée du Louvre
Naturagua
Naturajardin
Sotogrande
Tendo Garden
THE MAGIC GARDEN
Top Campo
Tutifruti S.A
Vivero Humanes
*/
