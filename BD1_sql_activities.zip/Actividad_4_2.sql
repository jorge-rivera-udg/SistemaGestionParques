use jardineria;

select nombrecliente, limitecredito from clientes where limitecredito in (select max(limitecredito) from clientes);
/*
nombrecliente, 		limitecredito
'Tendo Garden', 	'600000.00'
*/

select nombre, apellido1, puesto from empleados where codigoempleado not in (select codigoempleadorepventas from clientes where codigoempleadorepventas <> '');
/*
nombre, 	apellido1, 		puesto
'Marcos', 	'Magaña', 		'Director General'
'Carlos', 	'Soria', 		'Director Oficina'
'Francois', 'Fignon', 		'Director Oficina'
'Hilary', 	'Washington', 	'Director Oficina'
'Nei', 		'Nishikori', 	'Director Oficina'
'Amy', 		'Johnson', 		'Director Oficina'
'Kevin', 	'Fallmer', 		'Director Oficina'
'Juan Carlos', 'Ortiz', 	'Representante Ventas'
'Hilario', 	'Rodriguez', 	'Representante Ventas'
'David', 	'Palma', 		'Representante Ventas'
'Oscar', 	'Palma', 		'Representante Ventas'
'Laurent', 	'Serra', 		'Representante Ventas'
'Marcus', 	'Paxton', 		'Representante Ventas'
'Narumi', 	'Riko', 		'Representante Ventas'
'Takuma', 	'Nomura', 		'Representante Ventas'
'Larry', 	'Westfalls', 	'Representante Ventas'
'John', 	'Walton', 		'Representante Ventas'
'Maria', 	'Solís', 		'Secretaria'
'Ruben', 	'López', 		'Subdirector Marketing'
'Alberto', 	'Soria', 		'Subdirector Ventas'
*/

select nombre, precioventa, precioproveedor from productos where precioventa in (select max(precioventa) from productos);
/*
nombre, 					precioventa, 	precioproveedor
'Trachycarpus Fortunei', 	'462.00', 		'369.00'
*/

select nombre from productos where codigoproducto in (
		select codigoproducto from detallepedidos as dp where cantidad in (
				select max(cantidad) from detallepedidos
		)
);
/*
nombre
'Thymus Citriodra (Tomillo limón)'
*/

select nombrecliente, limitecredito from clientes where limitecredito > (
		select round(sum(preciounidad * cantidad), 2) from detallepedidos where codigopedido in (
				select codigopedido from pedidos group by codigocliente
        )
);
/*
De la actividad anterior, tenemos que la cantidad pagada total sin impuesto fue de 199,538
nombrecliente, 	limitecredito
'Tendo Garden', '600000.00'
'Dardena S.A.', '321000.00'
**/

select nombre, cantidadenstock from productos where codigoproducto in (
	select codigoproducto from productos where cantidadenstock in (
		select min(cantidadenstock) from productos
		union
		select max(cantidadenstock) from productos 
	)
);
/*
nombre							cantidadenstock
Rosal copa 						400
Albaricoquero Corbato			400
Albaricoquero Moniqui			400
Albaricoquero Kurrot			400
Cerezo Burlat					400
Cerezo Picota					400
Cerezo Napoleón					400
Ciruelo R. Claudia Verde   		400
Ciruelo Santa Rosa				400
Ciruelo Golden Japan			400
Ciruelo Friar					400
Ciruelo Reina C. De Ollins		400
Ciruelo Claudia Negra			400
Granado Mollar de Elche			400
Higuera Napolitana				400
Higuera Verdal					400
Higuera Breva					400
Manzano Starking Delicious		400
Manzano Reineta					400
Manzano Golden Delicious		400
Membrillero Gigante de Wranja	400
Melocotonero Spring Crest		400
Melocotonero Amarillo de Agosto	400
Melocotonero Federica			400
Melocotonero Paraguayo			400
Nogal Común						400
Parra Uva de Mesa				400
Peral Castell					400
Peral Williams					400
Peral Conference				400
Peral Blanq. de Aranjuez		400
Níspero Tanaca					400
Olivo Cipresino					400
Nectarina						400
Kaki Rojo Brillante				400
Brahea Armata				  	  0
*/