use nba;

select j.nombre, procedencia, nombre_equipo, ciudad from jugadores as j join equipos as e on e.nombre=j.nombre_equipo where procedencia = 'Spain';
/*
nombre, 				procedencia, 	nombre_equipo, 	ciudad
Juan Carlos Navarro, 	Spain, 			Grizzlies, 		Memphis
Pau Gasol, 				Spain, 			Lakers, 		Los Angeles
Jose Calderon, 			Spain, 			Raptors, 		Toronto
Jorge Garbajosa, 		Spain, 			Raptors, 		Toronto
Sergio Rodriguez, 		Spain, 			Trail Blazers, 	Portland
*/

select nombre from equipos where nombre like 'H%S';
/*
nombre
Hawks
Hornets
*/

select round(sum(puntos_por_partido),2) from estadisticas join jugadores on codigo=jugador where nombre = 'Pau Gasol'; 
/*
sum(puntos_por_partido)
132.2
*/

select nombre, conferencia from equipos where conferencia='west';
/*
nombre, 		conferencia
Clippers, 		West
Grizzlies, 		West
Hornets, 		West
Jazz, 			West
Kings, 			West
Lakers, 		West
Mavericks, 		West
Nuggets, 		West
Rockets, 		West
Spurs, 			West
Suns, 			West
Supersonics, 	West
Timberwolves, 	West
Trail Blazers,	West
Warriors, 		West
*/

select j.nombre, altura, peso, nombre_equipo as equipo from jugadores as j where procedencia='Arizona' and peso>220 and altura>'6-0';
/*
nombre, 			altura, peso, 	equipo
Luke Walton, 		6-8, 	235, 	Lakers
Loren Woods, 		7-2, 	260, 	Rockets
Channing Frye, 		6-11, 	248, 	Trail Blazers
Richard Jefferson, 	6-7, 	225,	Nets
*/

select nombre, round(avg(puntos_por_partido),2) as puntos from jugadores as j join estadisticas as e on jugador=codigo where nombre_equipo='cavaliers' group by nombre;
/*
nombre, 				puntos
Lance Allred, 			 0
Devin Brown, 			 6.6
Daniel Gibson, 			 7.65
Zydrunas Ilgauskas, 	14.29
LeBron James, 			27.36
Damon Jones, 			 6.43
Dwayne Jones, 			 1.07
Aleksandar Pavlovic, 	 6.1
Joe Smith, 				11.71
Eric Snow, 				 6.37
Wally Szczerbiak, 		15.09
Anderson Varejao,	 	 5.75
Ben Wallace, 			 6.16
Delonte West, 			 9.7
*/

select nombre from jugadores where nombre like '__v%';
/*
nombre
Javaris Crittenton
David Lee
Kevin Ollie
Devin Brown
Awvee Store
Kevin Garnett
Kevin Martin
David West
Devean George
Devin Harris
David Harrison
Kevin Durant
*/

select e.nombre, conferencia, count(j.nombre) as jugadores from jugadores as j join equipos as e on e.nombre=nombre_equipo where conferencia='west' group by e.nombre;
/*
nombre, 		conferencia, jugadores
Clippers,		West, 			15
Grizzlies, 		West, 			14
Hornets, 		West, 			14
Jazz, 			West, 			14
Kings, 			West, 			15
Lakers, 		West, 			15
Mavericks, 		West, 			15
Nuggets, 		West, 			13
Rockets, 		West, 			15
Spurs, 			West, 			15
Suns, 			West, 			13
Supersonics, 	West, 			15
Timberwolves, 	West, 			14
Trail Blazers,	West, 			15
Warriors, 		West, 			14
*/

select count(nombre) as argentinos from jugadores where procedencia='argentina';
/*
argentinos
6
*/

select max(puntos_por_partido) as promedio from jugadores as j join estadisticas as e on codigo=jugador where j.nombre='Lebron James';
/*
promedio
31.4
*/

select asistencias_por_partido as asistencias from jugadores as j join estadisticas as e on codigo=jugador where j.nombre='Jose Calderon' and temporada='07/08';
/*
promedio
31.4
*/

select temporada, puntos_por_partido as puntos from jugadores as j join estadisticas as e on codigo=jugador where j.nombre='Lebron James' and temporada>'02/03' and temporada<'06/07';
/*
temporada, puntos
03/04, 		20.9
04/05,	 	27.2
05/06, 		31.4
*/

select e.nombre, conferencia, count(j.nombre) as jugadores from jugadores as j join equipos as e on e.nombre=nombre_equipo where conferencia='east' group by e.nombre;
/*
nombre, 		conferencia, jugadores
76ers, 			East, 			14
Bobcats, 		East, 			14
Bucks, 			East, 			14
Bulls, 			East, 			15
Cavaliers, 		East, 			14
Celtics, 		East, 			15
Hawks, 			East, 			13
Heat, 			East, 			16
Knicks, 		East, 			15
Magic, 			East, 			15
Nets, 			East, 			14
Pacers, 		East, 			15
Pistons, 		East, 			15
Raptors, 		East, 			14
Wizards, 		East, 			13
*/

select nombre, round(avg(tapones_por_partido),2) as tapones from jugadores as j join estadisticas as e on jugador=codigo where nombre_equipo like '%blazers' group by nombre;
/*
nombre, 				tapones
LaMarcus Aldridge, 		1.2
Steve Blake, 			0.06
Channing Frye, 			0.53
Jarrett Jack, 			0.03
James Jones, 			0.38
Raef LaFremtz, 			1.34
Josh McRoberts, 		0
Travis Outlaw, 			0.03
Joel Przybilla, 		1.4
Sergio Rodriguez, 		0
Brandon Roy, 			0.2
Von Wafer, 				0.03
Martell Webster, 		0.27
*/

select conferencia, round(avg(rebotes_por_partido),2) as rebotes from jugadores as j join estadisticas as est join equipos as e on e.nombre=nombre_equipo and codigo=jugador where conferencia='east' group by conferencia;
/*
conferencia, 	rebotes
East, 			4.36
*/
