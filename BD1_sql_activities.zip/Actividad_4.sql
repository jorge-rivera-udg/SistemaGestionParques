use actividad3;

/* Sentencias del ejercicio 1, Cliente - Proveedor - Producto */
insert into ex1_cliente values('dni1','Carlos','Lopez','Nino perdido 100');
insert into ex1_cliente values('dni2','Pedro','Soto','Av. constitucion 2100');
insert into ex1_cliente values('dni3','Raul','Perez','cCerrada Alcanfor 100');

insert into ex1_proveedor values('nfi1', 'Fulano', 'Av. Revolucion 3000');
insert into ex1_proveedor values('nfi2', 'Sutano', 'Paseo Conquistador 1000');
insert into ex1_proveedor values('nfi3', 'Mengano', 'Puerto Madero 200');

insert into ex1_producto(nombre,precio,proveedor) values('impresora Epson L125',3500,'nfi1');
insert into ex1_producto(nombre,precio,proveedor) values('laptop DELL Latitude e5000', 23000, 'nfi3');
insert into ex1_producto(nombre,precio,proveedor) values('multifuncional Canon G3200', 4000, 'nfi2');

insert into ex1_prod_cli(fecha,folio,codigo,cliente) values('2026-02-02','nota1',1,'dni1');
insert into ex1_prod_cli(fecha,folio,codigo,cliente) values('2025-12-21','nota2',3,'dni2');
insert into ex1_prod_cli(fecha,folio,codigo,cliente) values('2025-12-06','nota3',2,'dni1');


select * from ex1_cliente;
select * from ex1_proveedor;
select * from ex1_producto;
select * from ex1_prod_cli;

update ex1_cliente set direccion='Cerrada Alcanfor 235' where dni='dni3';
update ex1_producto set nombre = 'Laptop DELL Latitude E5270' where proveedor = 'nfi3';

delete from ex1_prod_cli where id=3;

/* Sentencias del ejercicio 2, Camion - Camionero - Paquete - Provincia */
insert into ex2_camion values('sh-47456','Cascadia','Tractocamion','500hp');
insert into ex2_camion values('tu-03854','VNL 760','Full','560hp');
insert into ex2_camion values('ds-20578','LT Series','Tractocamion','450hp');

insert into ex2_camionero values('dni1','Juan','Calle Panal 364','3329857463','Cd Guzman',40000);
insert into ex2_camionero values('dni2','Pedro','Calle Nino perdido 295','3329857463','CDMX',39376);
insert into ex2_camionero values('dni3','Carlos','Juan Aldama 981','3329857463','Cuautla',42817);
insert into ex2_camionero values('dni4','francisco','Av Patria 180','3329857463','Zapopan',38275);

insert into ex2_provincia(nombre) values('Tonala');
insert into ex2_provincia(nombre) values('Tlaquepaque');
insert into ex2_provincia(nombre) values('El salto');
insert into ex2_provincia(nombre) values('Tequila');

insert into ex2_paquete(descripcion,destinatario,direccion,provincia,camionero) 
	values('paquete 1','Jose','Paseo de los abedules 2875',1,'dni4');
insert into ex2_paquete(descripcion,destinatario,direccion,provincia,camionero) 
	values('paquete 2','Jose','Paseo de los abedules 2875',1,'dni4');
insert into ex2_paquete(descripcion,destinatario,direccion,provincia,camionero) 
	values('paquete 3','Jose','Paseo de los abedules 2875',1,'dni4');

insert into ex2_camion_camionero(fecha,camion,camionero) values('2026-01-16','sh-47456','dni1');
insert into ex2_camion_camionero(fecha,camion,camionero) values('2025-12-22','tu-03854','dni4');
insert into ex2_camion_camionero(fecha,camion,camionero) values('2026-02-02','ds-20578','dni2');

select * from ex2_camion;
select * from ex2_camionero;
select * from ex2_provincia;
select * from ex2_paquete;
select * from ex2_camion_camionero;

update ex2_paquete set descripcion='paquete 2', destinatario='Arturo', 
	direccion='Av principal 1000', provincia=2, camionero='dni3' where codigo=2;
update ex2_paquete set descripcion='paquete 3', destinatario='Eduardo', 
	direccion='Paseo del conquistador 527', provincia=4, camionero='dni1' where codigo=3;
update ex2_camionero set nombre='Francisco' where dni='dni4';

delete from ex2_provincia where codigo=3;

/* Sentencias del ejercicio 3, Profesor - Modulo - Alumno - Grupo */
insert into ex3_profesor values('dni1', 'Alfredo','Aquiles Serdan 285', '2847563959');
insert into ex3_profesor values('dni2', 'Ramon','Domingo Diez 832', '2847563959');
insert into ex3_profesor values('dni3', 'Patricia','Vicente Guerrero 458', '2847563959');

select * from ex3_profesor;

insert into ex3_alumno values ('qwertyuio','Pedro','Lopez','2006-04-05');
insert into ex3_alumno values ('asdfghjkl','David','Perez','2008-10-25');
insert into ex3_alumno values ('zxcvbnmpq','Manuel','Ascencio','2007-02-09');

select * from ex3_alumno;

insert into ex3_modulo values('qazwsxedc','Materia 1','dni1');
insert into ex3_modulo values('rfvtgbyhn','Materia 2','dni2');
insert into ex3_modulo values('ujmikolpq','Materia 3','dni3');

select * from ex3_modulo;

insert into ex3_grupo values('grupo 1','qwertyuio','qazwsxedc');
insert into ex3_grupo values('grupo 2','asdfghjkl','rfvtgbyhn');
insert into ex3_grupo values('grupo 3','qwertyuio','ujmikolpq');
insert into ex3_grupo values('grupo 4','qwertyuio','rfvtgbyhn');

select * from ex3_grupo;

insert into ex3_mod_alum values('1','qwertyuio','qazwsxedc');
insert into ex3_mod_alum values('2','asdfghjkl','qazwsxedc');
insert into ex3_mod_alum values('3','zxcvbnmpq','qazwsxedc');

select * from ex3_mod_alum;

update ex3_profesor set telefono='9385726154' where dni='dni3';
update ex3_profesor set telefono='2875625423', nombre='Sofia' where dni='dni2';

delete from ex3_grupo where codigo='grupo 4';

/* Sentencias del ejercicio 4, Cliente - Coche - Revision */ 
insert into ex4_cliente values('dni1','Alvaro','Ninos heroes 837','CDMX','5572645327');
insert into ex4_cliente values('dni2','Jenifer','Division del norte 281','Patzcuaro','7493926748');
insert into ex4_cliente values('dni3','Paola','Abedul 345','Cuernavaca','7772514335');

select * from ex4_cliente;

insert into ex4_coche values('uyt-546-f','Volkswagen','Jetta','Rojo',125000,'dni3');
insert into ex4_coche values('yiu-789-e','Geely','Coolray','Blanco',415000,'dni1');
insert into ex4_coche values('ewr-748-w','GWM','Haval','Gris',534000,'dni2');

select * from ex4_coche;

insert into ex4_revision values('qazwsx123','Servicio-10000, cambio aceite, filtro aire, filtro cabina','2025-12-20','ewr-748-w');
insert into ex4_revision values('678bgtcdg','Servicio-20000, servicio-10000, balatas','2025-11-01','yiu-789-e');
insert into ex4_revision values('345kmbgeb','Servicio-120000','2025-10-23','uyt-546-f');

select * from ex4_revision;

update ex4_cliente set ciudad='Morelia' where dni='dni2';
update ex4_cliente set telefono='5568215642' where dni='dni1';

/* Sentencias de ejercicio 5, Medico - Paciente - Ingreso */

insert into ex5_medico values('cedula1','Rebeca','Cortes','Medicina general','8339636285');
insert into ex5_medico values('cedula2','Victor','Sanchez','Nutricion','3456528466');
insert into ex5_medico values('cedula3','Asucena','Martinez','Geriatria','9383658675');

select * from ex5_medico;

insert into ex5_paciente values('nss1','Paciente1','Apellido1','Direccion1','1234567890','Poblacion1','Provincia1','12345','1980-01-11');
insert into ex5_paciente values('nss2','Paciente2','Apellido2','Direccion2','1234567892','Poblacion2','Provincia2','12342','1990-02-12');
insert into ex5_paciente values('nss3','Paciente3','Apellido3','Direccion3','1234567893','Poblacion3','Provincia3','12343','1985-03-13');
insert into ex5_paciente values('nss4','Paciente4','Apellido4','Direccion4','1234567894','Poblacion4','Provincia4','12344','1995-04-14');

select * from ex5_paciente;

insert into ex5_ingreso(habitacion,cama,doctor,paciente) values('101',1,'cedula1','nss3');
insert into ex5_ingreso(habitacion,cama,doctor,paciente) values('208',2,'cedula3','nss2');
insert into ex5_ingreso(habitacion,cama,doctor,paciente) values('304',1,'cedula3','nss1');

select * from ex5_ingreso;

update ex5_medico set especialidad='Medicina interna' where codigo='cedula3';
update ex5_medico set especialidad='Ginecologia' where codigo='cedula2';

delete from ex5_paciente where codigo='nss4';
